import React, { useState } from 'react';
import logo from "./icons8-logo-100.png";
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useLocation } from "react-router-dom";


import {
  MenuUnfoldOutlined,
  UploadOutlined,
  UserOutlined,
  VideoCameraOutlined,
} from '@ant-design/icons';
import { Drawer, Layout, Menu, theme, Result, Button } from 'antd';
const { Header, Sider, Content } = Layout;

function MyMenu({ theme }) {
  const location = useLocation();
  const { pathname } = location;
 
  const items = [
    {
      key: '/',
      icon: <UserOutlined />,
      label: <Link to="/">Home</Link>
    },
    {
      key: '/about',
      icon: <VideoCameraOutlined />,
      label: <Link to="/about">关于我们</Link>
    },
    {
      key: '3',
      icon: <UploadOutlined />,
      label: '退出登录'
    }
  ]
  return (
    <>
      <Menu
        theme={theme}
        mode="inline"
        selectedKeys={[pathname]}
        items={items}
      />
    </>
  )
}

function Home() {
  return <h1>首页</h1>;
}

function About() {
  return <h1>关于我们</h1>;
}

// 404 页面
function NotFound() {
  const navigate = useNavigate();
  return (
    <Result
      status="404"
      title="404"
      subTitle="抱歉，您访问的页面不存在。"
      extra={
        <Button type="primary" onClick={() => navigate("/")}>
          返回首页
        </Button>
      }
    />
  );
}


const App = () => {
  const [collapsed, setCollapsed] = useState(false);

  const [open, setOpen] = useState(false);



  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();
  return (
    <Router>
      <Layout>
        <Header style={{ position: 'fixed', width: '100%', zIndex: 1, padding: 0 }}>
          {!collapsed ? <div style={{ width: '200px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <img src={logo} alt="Logo" style={{ height: '32px' }} />
          </div> : <div className="drawer-handle" style={{ height: '100%' }} onClick={() => setOpen(true)}>
            <MenuUnfoldOutlined style={{ fontSize: '24px', color: '#fff', marginLeft: '16px' }} />
          </div>
          }
        </Header>
        <Layout>
          <Sider trigger={null}
            style={{
              position: 'fixed',
              marginTop: '64px',
              width: '200px',
              height: '100vh'
            }}
            collapsed={collapsed}
            breakpoint='md'
            onBreakpoint={broken => {
              console.log(broken);
              setOpen(false)
              setCollapsed(broken)
            }}
            collapsedWidth='0'>
            <div className="demo-logo-vertical" />
            <MyMenu theme={"dark"} />
          </Sider>
          <Drawer
            placement='left'
            style={{ padding: 0 }}
            width={200}
            onClose={() => setOpen(false)}
            open={open}
          >
            <div className="demo-logo-vertical" />
            <MyMenu theme={"light"} />
          </Drawer>
          <Layout>
            <Content
              style={{
                overflow: 'initial',
                marginLeft: collapsed ? '0px' : "200px",
                marginTop: '64px'
              }}
            >
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/about" element={<About />} />
                <Route path="/*" element={<NotFound />} />
              </Routes>
            </Content>
          </Layout>

        </Layout>
      </Layout>
    </Router>
  );
};
export default App;